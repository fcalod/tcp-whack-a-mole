package main

import (
	"sync"
)

func addPlayer(nombre string, ipAddress string, jugadoresMux *sync.Mutex, jugadores *map[string]struct{}) {

}

func removePlayers(jugadoresMux *sync.Mutex, jugadores *map[string]struct{}) {

}
